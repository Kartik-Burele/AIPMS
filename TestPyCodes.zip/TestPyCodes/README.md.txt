1. Follow the link for installation
https://docs.privategpt.dev/installation/getting-started/installation

2. setting env variable is important 
$env:PGPT_PROFILES="ollama"
make run

