from gradio_client import Client, handle_file
import fitz
from docx import Document
from docx.shared import RGBColor

client = Client("http://localhost:8001/")

def read_file(file_path):
    try:
        with fitz.open(file_path) as doc:
            content = ""
            for page in doc:
                content += page.get_text() + "\n"
        return content
    except FileNotFoundError:
        return "File not found. Please check the file path."
    except Exception as e:
        return f"An error occurred: {e}"

def Generate_Prompt(RFQ_text):
    # print("DEBUG:",RFQ_text)
    Prompt_1 = client.predict(
		message=f'Give me project scope in paragraph format from {RFQ_text} in 100 words. Project scope should start with "The objective of the project is"',
		mode="RAG",
		param_3=[handle_file(r"K:\PrivateAI\PDF_RAG_APP\data\sample1.pdf")],
		param_4="""You can only answer questions about the provided context.
    If you know the answer but it is not based in the provided context, don't provide
    the answer, just state the answer is not in the context provided.""",
		api_name="/chat"
	)
    
    return Prompt_1

def save_to_txt(data: str, filename: str):
    """
    Saves the given string data into a .txt file.
    
    :param data: The string content to be saved.
    :param filename: The name of the output text file.
    """
    if not filename.endswith(".doc"):
        filename += ".doc"
    
    try:
        with open(filename, "w", encoding="utf-8") as file:
            file.write(data)
        print(f"Data successfully saved to {filename}")
    except Exception as e:
        print(f"Error saving file: {e}")

def get_text_before_sources(text: str) -> str:
    """Returns the substring before the word 'sources' in the given text."""
    keyword = "<hr>Sources"
    index = text.find(keyword)
    if index != -1:
        return text[:index].strip()
    return text

def beautify_text(input_text, keywords, output_file):
    try:
        # Create a Word document
        doc = Document()
        
        # Add content to the document
        for line in input_text.split('\n'):
            p = doc.add_paragraph()
            words = line.split()
            
            for word in words:
                if word in keywords:
                    run = p.add_run(word + ' ')
                    run.bold = True
                    run.font.color.rgb = RGBColor(0, 0, 255)  # Blue color
                else:
                    p.add_run(word + ' ')
        
        # Save as .docx file
        doc.save(output_file)
        
        print(f"Processed file saved as: {output_file}")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == '__main__' :
    
	DocPath = r"C:\Users\burel\Downloads\TestPyCodes\RFQ\RFQ.pdf"

	Read_text = read_file(DocPath)
	ai_text = Generate_Prompt(Read_text)
	Prompt_1 = get_text_before_sources(ai_text)
    
	print("DEBUG Prompt_1:",Prompt_1)
	result = client.predict(
			
			# message=f'Generate the output maintaing the formating as per the data for {Prompt_1}.',
            message=f'Generate the output in the exact same format of provided data for {Prompt_1}.',
			mode="RAG",
			param_3=[handle_file(r"K:\PrivateAI\PDF_RAG_APP\data\sample1.pdf")],
            
			param_4="""You can only answer questions about the provided context.
	    If you know the answer but it is not based in the provided context, don't provide
	    the answer, just state the answer is not in the context provided.""",
			api_name="/chat"
)
# save_to_txt(get_text_before_sources(result),'Output_1.doc')
beautify_text(get_text_before_sources(result),["Scope", "Objective", "Stage", "developments", "Schedule", "Budgetary", "Estimation"],'Output_1.doc')